"""
start_server.py - aiohttp Web Server for Teams NL2SQL Bot
==========================================================

This module starts an aiohttp web server that hosts the /api/messages endpoint
for the Microsoft Teams bot. It uses the M365 Agents SDK to handle incoming
messages and route them to the agent application.

Based on Microsoft 365 Agents SDK quickstart sample pattern.
"""

from os import environ
from microsoft_agents.hosting.core import AgentApplication, AgentAuthConfiguration
from microsoft_agents.hosting.aiohttp import (
    start_agent_process,
    jwt_authorization_middleware,
    CloudAdapter,
)
from aiohttp.web import Request, Response, Application, run_app

# Import our Teams NL2SQL agent
from teams_nl2sql_agent import AGENT_APP, CONNECTION_MANAGER


def start_server(
    agent_application: AgentApplication, 
    auth_configuration: AgentAuthConfiguration
):
    """
    Start the aiohttp web server with the Teams bot endpoint.
    
    Args:
        agent_application: The configured AgentApplication instance
        auth_configuration: Authentication configuration from MsalConnectionManager
    """
    
    async def entry_point(req: Request) -> Response:
        """
        Entry point for /api/messages endpoint.
        Routes incoming Bot Framework activities to the agent application.
        """
        agent: AgentApplication = req.app["agent_app"]
        adapter: CloudAdapter = req.app["adapter"]
        return await start_agent_process(
            req,
            agent,
            adapter,
        )

    # Create aiohttp application with JWT authorization middleware
    APP = Application(middlewares=[jwt_authorization_middleware])
    
    # Register the /api/messages endpoint
    APP.router.add_post("/api/messages", entry_point)
    
    # Store configuration in app context
    APP["agent_configuration"] = auth_configuration
    APP["agent_app"] = agent_application
    APP["adapter"] = agent_application.adapter

    # Get port from environment or default to 3978 (standard bot port)
    # Azure App Service uses PORT environment variable
    port = int(environ.get("PORT", 3978))
    # Use 0.0.0.0 for Azure, localhost for local development
    host = environ.get("HOST", "0.0.0.0" if environ.get("WEBSITE_SITE_NAME") else "localhost")

    print(f"\n{'='*60}")
    print(f"🤖 NL2SQL Teams Bot Server Starting...")
    print(f"{'='*60}")
    print(f"Host: {host}")
    print(f"Port: {port}")
    print(f"Endpoint: http://{host}:{port}/api/messages")
    print(f"{'='*60}\n")

    try:
        run_app(APP, host=host, port=port)
    except Exception as error:
        print(f"[ERROR] Failed to start server: {error}")
        raise error


if __name__ == "__main__":
    # Enable logging for debugging
    import logging
    ms_agents_logger = logging.getLogger("microsoft_agents")
    ms_agents_logger.addHandler(logging.StreamHandler())
    ms_agents_logger.setLevel(logging.INFO)
    
    print("Starting NL2SQL Teams Bot...")
    
    # Start the server with our agent application
    start_server(
        agent_application=AGENT_APP,
        auth_configuration=CONNECTION_MANAGER.get_default_connection_configuration(),
    )

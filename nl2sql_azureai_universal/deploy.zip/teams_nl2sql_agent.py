"""
teams_nl2sql_agent.py - Microsoft Teams Bot Wrapper for NL2SQL Pipeline
========================================================================

This module wraps the existing NL2SQL pipeline (nl2sql_main.py) with the
Microsoft 365 Agents SDK to enable natural language database queries via Teams.

Architecture:
- Teams message → M365 Agent → NL2SQL pipeline → SQL execution → Teams response
- Reuses 90%+ of existing NL2SQL code
- Thin wrapper layer for Teams messaging

Requirements:
- Microsoft 365 Agents SDK packages (from TestPyPI)
- Azure Bot Service registration
- Environment variables for bot authentication
"""

import os
import sys
from typing import Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import M365 Agents SDK
try:
    from microsoft_agents.hosting.core import (
        Authorization,
        AgentApplication,
        TurnState,
        TurnContext,
        MemoryStorage,
        MessageFactory,
    )
    from microsoft_agents.activity import load_configuration_from_env, ActivityTypes
    from microsoft_agents.hosting.aiohttp import CloudAdapter
    from microsoft_agents.authentication.msal import MsalConnectionManager
except ImportError as e:
    print("[ERROR] Failed to import Microsoft 365 Agents SDK packages.")
    print("Please install the required packages from TestPyPI:")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-core")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-authorization")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-connector")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-builder")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-authentication-msal")
    print("  pip install -i https://test.pypi.org/simple/ microsoft-agents-hosting-aiohttp")
    sys.exit(1)

# Import our existing NL2SQL functions
try:
    from nl2sql_main import (
        process_nl_query,
        extract_intent,
        generate_sql,
        execute_and_format,
        get_token_usage
    )
except ImportError as e:
    print(f"[ERROR] Failed to import NL2SQL functions: {e}")
    print("Make sure nl2sql_main.py is in the same directory.")
    sys.exit(1)


# ========== CONFIGURATION ==========

# Load configuration from environment using SDK helper
agents_sdk_config = load_configuration_from_env(os.environ)

# ========== INITIALIZE M365 AGENTS SDK COMPONENTS ==========

# Create storage (in-memory for now, can switch to BlobStorage/CosmosDB later)
STORAGE = MemoryStorage()

# Create MSAL connection manager for authentication
CONNECTION_MANAGER = MsalConnectionManager(**agents_sdk_config)

# Create cloud adapter for Bot Service communication
ADAPTER = CloudAdapter(connection_manager=CONNECTION_MANAGER)

# Create Authorization (for OAuth scenarios)
AUTHORIZATION = Authorization(STORAGE, CONNECTION_MANAGER, **agents_sdk_config)

# Create agent application
AGENT_APP = AgentApplication[TurnState](
    storage=STORAGE,
    adapter=ADAPTER,
    authorization=AUTHORIZATION,
    **agents_sdk_config
)


# ========== EVENT HANDLERS ==========

@AGENT_APP.conversation_update("membersAdded")
async def on_members_added(context: TurnContext, state: TurnState):
    """
    Handle new members added to conversation (welcome message).
    """
    for member in context.activity.members_added:
        if member.id != context.activity.recipient.id:
            welcome_message = """👋 **Welcome to NL2SQL Bot!**

I can help you query databases using natural language. Just ask me questions like:
- "How many customers do we have?"
- "Show me loans with balance over $10,000"
- "What's the average loan amount by state?"
- "List customers who joined in the last 30 days"

I'll convert your question to SQL, execute it, and show you the results!

**Powered by Azure AI Agents** 🤖"""
            
            await context.send_activity(MessageFactory.text(welcome_message))


@AGENT_APP.activity(ActivityTypes.message)
async def on_message(context: TurnContext, state: TurnState):
    """
    Handle incoming messages - this is where the NL2SQL magic happens!
    """
    user_query = context.activity.text
    
    if not user_query or not user_query.strip():
        await context.send_activity("Please provide a query.")
        return
    
    # Handle help command
    if user_query.strip().lower() in ["/help", "help", "?"]:
        help_message = """**NL2SQL Bot Commands:**

Just type your natural language question to query the database!

**Examples:**
- Count records: "How many loans are active?"
- Filter data: "Show customers in California"
- Aggregate: "What's the total loan amount by state?"
- Complex: "List top 10 customers by loan balance"

**Special Commands:**
- `/help` - Show this help message
- `/about` - About this bot

The bot will:
1. 🧠 Extract intent from your question
2. 💡 Generate SQL query
3. ⚡ Execute against the database
4. 📊 Format and return results"""
        
        await context.send_activity(MessageFactory.text(help_message))
        return
    
    # Handle about command
    if user_query.strip().lower() in ["/about", "about"]:
        about_message = """**NL2SQL Bot** - Natural Language to SQL Query Assistant

**Technology Stack:**
- 🤖 Microsoft 365 Agents SDK
- 🧠 Azure AI Foundry Agent Service
- 💾 Azure SQL Database
- 🔗 Python + aiohttp

**Architecture:**
Teams → M365 Agent → Azure AI → SQL → Results

**Code Reuse:** 90%+ of existing NL2SQL pipeline

Built with ❤️ for seamless database querying in Teams!"""
        
        await context.send_activity(MessageFactory.text(about_message))
        return
    
    # Send typing indicator
    await context.send_activity(MessageFactory.text("🤔 Processing your query..."))
    
    try:
        # Call the NL2SQL pipeline
        result = process_nl_query(user_query, execute=True)
        
        # Format response
        response_message = _format_response(user_query, result)
        
        # Send response
        await context.send_activity(MessageFactory.text(response_message))
        
    except Exception as e:
        error_message = f"❌ **Error processing query**\n\n{str(e)}\n\nPlease try rephrasing your question or contact support."
        await context.send_activity(MessageFactory.text(error_message))
        print(f"[ERROR] Exception in on_message: {e}", file=sys.stderr)


@AGENT_APP.error
async def on_error(context: TurnContext, error: Exception):
    """
    Global error handler for the agent.
    """
    print(f"[ERROR] Unhandled exception: {error}", file=sys.stderr)
    
    # Send a friendly error message to the user
    error_message = """❌ **Oops! Something went wrong.**

I encountered an error while processing your request. Please try again or rephrase your question.

If the problem persists, contact the bot administrator."""
    
    try:
        await context.send_activity(MessageFactory.text(error_message))
    except Exception:
        # If we can't even send an error message, just log it
        print("[ERROR] Failed to send error message to user", file=sys.stderr)


# ========== HELPER FUNCTIONS ==========

def _format_response(query: str, result: dict) -> str:
    """
    Format the NL2SQL pipeline result into a Teams-friendly message.
    
    Args:
        query: Original user query
        result: Result dictionary from process_nl_query()
    
    Returns:
        Formatted markdown message for Teams
    """
    lines = []
    
    # Header
    lines.append("✅ **Query Results**")
    lines.append("")
    
    # Show SQL query
    lines.append("**Generated SQL:**")
    lines.append("```sql")
    lines.append(result.get("sql", "N/A"))
    lines.append("```")
    lines.append("")
    
    # Show results
    if "results" in result and result["results"].get("success"):
        rows = result["results"].get("rows", [])
        count = result["results"].get("count", 0)
        
        lines.append(f"**Found {count} result(s):**")
        lines.append("")
        
        if count == 0:
            lines.append("_No rows returned._")
        elif count <= 10:
            # Show all rows as formatted table
            lines.append(_format_rows_as_table(rows))
        else:
            # Show first 10 rows + message
            lines.append(_format_rows_as_table(rows[:10]))
            lines.append("")
            lines.append(f"_Showing first 10 of {count} results. Query returned {count - 10} more rows._")
    else:
        # Execution error
        error_msg = result.get("results", {}).get("error", "Unknown error")
        lines.append(f"❌ **Execution Error:**")
        lines.append(f"```")
        lines.append(error_msg)
        lines.append("```")
    
    # Token usage (optional, for monitoring)
    token_usage = result.get("token_usage", {})
    if token_usage:
        total = token_usage.get("total", 0)
        lines.append("")
        lines.append(f"_Tokens used: {total}_")
    
    return "\n".join(lines)


def _format_rows_as_table(rows: list) -> str:
    """
    Format query result rows as a simple text table.
    
    Args:
        rows: List of dictionaries (query results)
    
    Returns:
        Formatted table string
    """
    if not rows:
        return "_No rows_"
    
    # Get columns
    columns = list(rows[0].keys())
    
    # Calculate column widths
    col_widths = {}
    for col in columns:
        col_widths[col] = max(len(str(col)), max(len(str(row.get(col, ""))) for row in rows))
    
    # Build table
    lines = []
    
    # Header
    header = " | ".join(str(col).ljust(col_widths[col]) for col in columns)
    lines.append(header)
    
    # Separator
    separator = "-+-".join("-" * col_widths[col] for col in columns)
    lines.append(separator)
    
    # Rows
    for row in rows:
        row_str = " | ".join(str(row.get(col, "")).ljust(col_widths[col]) for col in columns)
        lines.append(row_str)
    
    return "```\n" + "\n".join(lines) + "\n```"


# ========== EXPORTS ==========

# Export agent application for use by start_server.py
__all__ = [
    "AGENT_APP",
    "ADAPTER",
    "CONNECTION_MANAGER",
    "STORAGE"
]


if __name__ == "__main__":
    print("teams_nl2sql_agent.py - This module should be imported by start_server.py")
    print("Run: python start_server.py")
